// ------------------------------------------------------
// Curso de C# desde 0
// Clase 12 Operadores Precedencia
// ------------------------------------------------------

// En una expresión, las operaciones normalmente se
// ejecutan de izquierda a derecha, pero lo deben
// hacer respetando la precedencia de los operadores.

// La precedencia de operadores, es el orden en que se
// ejecutan las operaciones en una expresión, en relación
// a la jerarquía de los operadores.

// Hay operadores que tienen mayor jerarquía que otros,
// esto significa que se deben de ejecutar primero.

// Por ejemplo:
// 5 + 4 + 3 

// En la anterior expresión, la multiplicación de 4 * 3
// se debe realizar primero ya que la multiplicación
// tiene mayor precedencia o jerarquía que la suma

// A continuación se muestra la lista de operadores
// Los que están en la parte superior tienen mayor
// precedencia que los que están debajo

// Operadores	             
// () [] -> . ++ - -	
// + - ! ~ ++ - - (type)* & sizeof	(Unarios)
// * / %	
//	+ -	
// << >>
//	< <= > >=	
//	== !=	
//	&	
// ^	
// |	
// &&	
// ||	
//	?:	
//	= += -= *= /= %=>>= <<= &= ^= |=
// ,

// Ejemplos
// 5 +  4 * 10 > (5 + 6) +  2 * 5
// 5 + 40      > 11      + 10
// 45          > 21
// True

// 5 * 2 << 1 / 4 + 3 >> 1
// 10    << 0     + 3 >> 1
// 10    << 3         >> 1
// 80                 >> 1
// 40

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {      
      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 12 Operadores Precedencia");

      // Desplegamos la operación
      Console.WriteLine("5 +  4 * 10 > (5 + 6) +  2 * 5 : ");
      Console.WriteLine( 5 +  4 * 10 > (5 + 6) +  2 * 5 );         

      // Desplegamos la operación
      Console.WriteLine("5 * 2 << 1 / 4 + 3 >> 1 :");
      Console.WriteLine( 5 * 2 << 1 / 4 + 3 >> 1 );         
   }
}