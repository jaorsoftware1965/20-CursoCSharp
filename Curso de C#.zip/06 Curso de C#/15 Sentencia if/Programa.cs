// ---------------------------------------------------------
// Curso de C# desde 0
// Clase 15 Sentencia if
// ---------------------------------------------------------

// La Sentencia if es la sentencia por excelencia
// que controla el flujo de un programa y lo
// realiza evaluando condiciones.

// Se utiliza con otras 2 palabras reservadas: else y else if

// if (condicion)
// {
//    Instrucciones a ajecutar si se cumple condición
// }
// else
// {
//    Instrucciones a ajecutar si NO se cumple condición
// }

// if (condicion)
// {
//    Instrucciones a ajecutar si se cumple condición
// }
// else if (condicion)
//      {
//          Instrucciones a ajecutar si se cumple condición
//      }


// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {         
      // Variables
      int    iEdad;

      // Solicitamos la Edad
      Console.WriteLine("Edad:");
      iEdad = Convert.ToInt32(Console.ReadLine());

      // Verifica si eres mayor de edad
      if (iEdad >=18)
      {
         // Mensaje de Mayor de Edad
         Console.WriteLine("Eres un Adulto mayor de Edad ");
      }
      else
      {
         // Mensaje de Menor de Edad
         Console.WriteLine("Eres menor de Edad ");
      }


      // Verifica si eres mayor de edad
      if (iEdad < 18)
      {
         // Mensaje de Mayor de Edad
         Console.WriteLine("Eres menor de Edad ");
      }
      else if (iEdad >= 65)
      {
         // Mensaje de Menor de Edad
         Console.WriteLine("Estas en la Tercera Edad ");
      }
      else
      {
         // Mensaje de Mayor de Edad
         Console.WriteLine("Eres un Adulto Mayor de Edad ");
      }      
   }
}