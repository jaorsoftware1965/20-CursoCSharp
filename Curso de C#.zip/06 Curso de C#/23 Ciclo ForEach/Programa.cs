// ---------------------------------------------------------
// Curso de C# desde 0
// Clase 21 Arreglos
// -------------------------------------------------------------------

// Un Arreglo es una variable en la cual puedes depositar
// mas de un valor; y para acceder a cada valor lo haces
// a través de un índice; partiendo de 0


// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {     
      // Declare a single-dimensional array of 5 integers.
        int[] array1 = new int[3];

        // Declare and set array element values.
        int[] array2 = new int[] { 1, 3, 5, 7, 9 };

        // Alternative syntax.
        int[] array3 = { 1, 2, 3, 4, 5, 6,7 };

        // Asignamos valores
        array1[0]= 13;

        // Ciclo para desplegar cada arreglo
        for (int i = 0; i < array1.Length; i++) 
        {
            // Desplegamos el dato
            Console.Write("["+array1[i]+"]");
        }
        Console.WriteLine();

        // Ciclo para desplegar cada arreglo
        for (int i = 0; i < array2.Length; i++) 
        {
            // Desplegamos el dato
            Console.Write("["+array2[i]+"]");
        }
        Console.WriteLine();

        // Ciclo para desplegar cada arreglo
        for (int i = 0; i < array3.Length; i++) 
        {
            // Desplegamos el dato
            Console.Write("["+array3[i]+"]");
        }
        Console.WriteLine();

   }    
}