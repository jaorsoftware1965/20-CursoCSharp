class HolaMundo
{
   public static void Main()
   {
      System.Console.WriteLine("Hola Mundo");
   }
}