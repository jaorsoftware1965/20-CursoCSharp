// ----------------------------------------
// Clase 05 Entrada de Datos
// ----------------------------------------

// En las clases anteriores hemos visto como desplegar datos en la pantalla
// Ahora en esta clase veremos como capturar datos desde el teclado; es decir;
// que el usuario capture algo y nosotros sepamos que es.
// Para lograrlo hacemos uso de la función: Console.ReadLine();

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 05 Entrada de Datos");

      // Mensaje para solicitar el nombre
      Console.WriteLine("Capture su nombre:");

      // Creamos una variable y a su vez ejecutamos la función para que lea
      string sNombre;
      sNombre = Console.ReadLine();

      // Desplegamos lo capturado por el Usuario
      Console.WriteLine("Tu nombre es: " + sNombre);
   }
}