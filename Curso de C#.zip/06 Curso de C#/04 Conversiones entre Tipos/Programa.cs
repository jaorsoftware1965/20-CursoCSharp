// ----------------------------------------
// Clase 04 Conversiones entre tipos (Cast)
// ----------------------------------------

// La conversión entre tipos o casting, sucede cuando se
// asignan valores que no son correspondientes al tipo de la variable
// a la cual se está asignando

// En C#, hay 2 tipos de conversiones

// Implicita (automatica) Convertir un valor pequeño a uno mayor
// Ejemplo:
// char -> int -> long -> float -> double

// Explicito (manually) - Convertir un valor mas grande a uno pequeño
// Ejemplos:
// double -> float -> long -> int -> char

// Métodos de Conversión. Existen métodos que permite convertir mas claramente
// valores entre tipo. Son los siguientes:
// Convert.ToBoolean
// Convert.ToDouble
// Convert.ToString, 
// Convert.ToInt32 (int) y 
// Convert.ToInt64 (long):

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 04 Conversión entre tipos (Cast)");

      // Ejemplo de conversión implicita
      // Declaro una variable entera y una doble
      int    xEntera = 9;
      double xDoble  = xEntera;  // Automatic convierte de int a double

      // Desplegamos
      Console.WriteLine(xEntera);  // Despliega 9
      Console.WriteLine(xDoble);   // Despliega 9

      // Ejemplo de conversión explicita o manual
      double  dPeso = 99.78;
      int     iPeso = (int) dPeso;  // Convierto de Double a Integer

      // Desplegamos
      Console.WriteLine(dPeso); // Despliega 99.78
      Console.WriteLine(iPeso); // Despliega 99    

      // Métodos de Conversión
      int    iEntero    = 10;
      double dDouble    = 5.25;
      bool   bBooleana  = true;
            
      Console.WriteLine("1)" + Convert.ToString(iEntero));    
      Console.WriteLine("2)" + Convert.ToDouble(iEntero));    
      Console.WriteLine("3)" + Convert.ToInt32(dDouble));  
      Console.WriteLine("4)" + Convert.ToString(bBooleana)+'\n');   

      // Variable para obener las cadenas
      string sCadena1, sCadena2;

      // Obtenemos los valores
      sCadena1 = Convert.ToString(iEntero);
      iEntero  = Convert.ToInt32(dDouble);
      dDouble  = Convert.ToDouble(iEntero);      
      sCadena2 = Convert.ToString(bBooleana);

      // Desplegamos
      Console.WriteLine("5)" + sCadena1);    
      Console.WriteLine("6)" + iEntero);    
      Console.WriteLine("7)" + dDouble);  
      Console.WriteLine("8)" + sCadena2);   
   }
}