// ---------------------
// Clase 01 Introducción
// ---------------------

// Comentarios
// Estructura de un Programa en C#
// Distingue entre mayusculas y minusculas

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 01 Introducción");
   }
}