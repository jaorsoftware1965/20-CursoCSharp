// ---------------------------------------------------------
// Curso de C# desde 0
// Clase 19 Ciclo For y Foreach
// -------------------------------------------------------------------

// El Ciclo for es una forma mas explícita de implementar un ciclo While
// Nos permite establecer un ciclo en el cual se indica el numero de veces
// que se repetirán las instrucciones

// for (statement 1; statement 2; statement 3) 
// {
       // code block to be executed
// }

// Existe otro ciclo for, llamado foreach, el cual realiza un recorrido
// en una colección de datos.

// foreach (type variableName in arrayName) 
// {
     // code block to be executed
// }


// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {         
      for (int i = 10; i >= 1; i--) 
      {
         Console.WriteLine(i);
      }

      // Deja una linea
      Console.WriteLine();

      string sVariable ="Otro Mensaje";

      // Ciclo foreach
      foreach (char i in sVariable) 
      {
         Console.WriteLine(i);
      }

      // Deja una linea
      Console.WriteLine();

      // Variable boolean
      Boolean bEjecutarCiclo = true;

      for (int i = 0; bEjecutarCiclo; i++) 
      {
         if (i == 3)         
            bEjecutarCiclo = false;
         Console.WriteLine(i);
      }
   }    
}