// -----------------------------------
// Clase 02 Variables y Tipos de Datos
// -----------------------------------

// Que es un tipo de datos

// Type	   Size	Default  Rango 
// int	      4  0        -2,147,483,648 / 2,147,483,647
// long	      8  0        -9,223,372,036,854,775,808 / 9,223,372,036,854,775,807
// float	      4  0.0F     -3.4 x 10e38 / +3.4 x 10e38
// double	   8  0.0D     (+/-)5.0 x 10e-324 a (+/-)1.7 x 10e308
// bool	      1  false    true / false
// char	      2  '\0'     
// string	   2  ""       2 bytes por caracter

// Que es una variable
// Es un espacio de memoria al cual se le asigna un nombre y se le indica un
// tipo de dato, para poder almacenar valores en ella.

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 02 Variables y Tipos de Datos");

      // Ejemplos de Tipos de Datos y Variables
      int      iEdad      = 55;               
      long     lValor     = 1231231233123;    
      float    fEstatura  = 1.82F;
      double   dPeso      = 99.5D;           
      char     cLetra     = 'D';         
      bool     bCasado    = true;        
      string   sNombre    = "Pedro Perez";     

      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("-----------------------------");
      System.Console.WriteLine("Edad     :" + iEdad);
      System.Console.WriteLine("Valor    :" + lValor);
      System.Console.WriteLine("Estatura :" + fEstatura);
      System.Console.WriteLine("Peso     :" + dPeso);
      System.Console.WriteLine("Letra    :" + cLetra);
      System.Console.WriteLine("Casado   :" + bCasado);
      System.Console.WriteLine("Nombre   :" + sNombre);

      // Modifico las variables
      iEdad      = 75;               
      lValor     = 7231231233123;    
      fEstatura  = 7.82F;
      dPeso      = 79.5D;            
      cLetra     = '7';         
      bCasado    = false;        
      sNombre    = "Pedro Ramirez";     

      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("-----------------------------");
      System.Console.WriteLine("Edad     :" + iEdad);
      System.Console.WriteLine("Valor    :" + lValor);
      System.Console.WriteLine("Estatura :" + fEstatura);
      System.Console.WriteLine("Peso     :" + dPeso);
      System.Console.WriteLine("Letra    :" + cLetra);
      System.Console.WriteLine("Casado   :" + bCasado);
      System.Console.WriteLine("Nombre   :" + sNombre);
   }
}