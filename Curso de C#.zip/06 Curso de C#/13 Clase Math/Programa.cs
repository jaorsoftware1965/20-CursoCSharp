// ---------------------------------------------------------
// Curso de C# desde 0
// Clase 13 Clase Math
// ---------------------------------------------------------

// La Clase Math nos proporciona algunas funcionas numéricas
// importantes.

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {         
      Console.WriteLine("Max(9,99)  :" + Math.Max(9,99));
      Console.WriteLine("Min(9,99)  :" + Math.Min(9,99));
      Console.WriteLine("Sqrt(64)   :" + Math.Sqrt(64));
      Console.WriteLine("Abs(-9.99) :" + Math.Abs(-9.99));
      Console.WriteLine("Round(9.99):" + Math.Round(9.99));
   }
}