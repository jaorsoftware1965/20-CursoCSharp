// ----------------------------------------
// Curso de C# desde 0
// Clase 11 Operadores Varios
// ----------------------------------------

// Existen otros operadores que no están en alguna categoría y son:

// Operador    Descripción                            Ejempo
// sizeof()	   Obtiene el tamaño de un Tipo-Dato	   sizeof(int)
// typeof()	   Obtiene el Tipo de la Clase	         typeof(StreamReader);
// ? :	      Operador Condicional	/ Ternario        condicion ? val1 : val2
// is	         Verificar Tipo de un Objeto 	         If( Ford is Car) 

// &	         Obtiene la dirección de una variable	&a 
// *	         Apuntador a una variable	            *a
// as	         Cast sin excepción en caso de error    StringReader r = obj as StringReader;

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Declaramos variables
      int    a, b;
      string nombre="Juan Perez";

      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 11 Operadores Varios");

      /* Desplegamos los Tamaños de los tipos de dato */
      Console.WriteLine("El Tamaño de int       es: {0}", sizeof(int));
      Console.WriteLine("El Tamaño de short     es: {0}", sizeof(short));
      Console.WriteLine("El Tamaño de double    es: {0}", sizeof(double));
      Console.WriteLine("El TipoDato de a       es: {0}", typeof(string));
      Console.WriteLine("Variable nombre es string: {0}", nombre is string);

      // Asignamos valor 
      a = 10;

      // Usamos operador Condicional o Ternario
      b = (a == 1) ? 20 : 30;  // Si a es igual a 1 asigna 20 si no; 30

      // Desplegamos el valor de la variable b
      Console.WriteLine("Valor de b es: {0}", b);

      // Usamos operador condicional
      b = (a == 10) ? 20 : 30;

      // Desplegamos valor de b
      Console.WriteLine("Valor de b es: {0}", b);           

      nombre = (a==10) ? "Maria Morales" : "Fulano de Tal";
      Console.WriteLine("Valor de nombre es: {0}", nombre);           
   }
}