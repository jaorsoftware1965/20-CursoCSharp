// ---------------------------------------------------------
// Curso de C# desde 0
// Clase 17 Operador Condicional o Ternario
// -------------------------------------------------------------------

// El operador condicional, su sintaxis es la siguiente:

// condición ? valor retornar si es true : valor retornar si es falso


// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {         
      // Variables
      int    x = 10;
      int    y = 5;
      int    z = 7;
      int    iValorMayor;
      string sValorMayor;

      // Obtiene el valor Mayor
      iValorMayor = x > y ? x : y; 

      // Creamos una variable y a su vez ejecutamos la función para que lea
      Console.WriteLine("El valor mayor es:"+iValorMayor);

      // Obtiene el valort Mayor
      sValorMayor = x > y ? "x" : "y"; 

      // Creamos una variable y a su vez ejecutamos la función para que lea
      Console.WriteLine("La variable Mayor es:"+sValorMayor);
      Console.WriteLine();

      // Creamos una variable y a su vez ejecutamos la función para que lea
      Console.WriteLine("El valor Mayor es:"    + (x > y ? x : y));
      Console.WriteLine("La variable Mayor es:" + (x > y ? "x" : "y"));
      Console.WriteLine();

      // Obtiene el valor Mayor
      iValorMayor = x > y ? x > z ? x : z : y;       
      Console.WriteLine("El valor mayor es:"+iValorMayor);

      if (x > y)
      {
         if (x > z)
         {
            iValorMayor = x;
         }
         else
         {
             iValorMayor = y;
         }
      }
      else
      {
         iValorMayor = z;
      }
      Console.WriteLine("El valor mayor es:"+iValorMayor);
   }    
}