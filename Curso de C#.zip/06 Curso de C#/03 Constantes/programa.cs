// -----------------------------------
// Clase 03 Constantes
// -----------------------------------

// Una constante es una variable a la cual se le asigna un valor
// y este es fijo y no se puede modificar; durante la ejecución 
// del programa

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 03 Constantes");

      // Ejemplos de Constantes
      const float    FLT_PI         = 3.1416F;
      const double   DOU_IVA        = 1.15D;           
      const char     CHR_MONEDA     = '$';
      const string   STR_APLICACION = "Mi Sistema";
      
      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("PI         :" + FLT_PI);
      System.Console.WriteLine("IVA        :" + DOU_IVA);
      System.Console.WriteLine("MONEDA     :" + CHR_MONEDA);
      System.Console.WriteLine("APLICACION :" + STR_APLICACION);

      // Intento Modificar constante
      FLT_PI  = 75;               
      
   }
}