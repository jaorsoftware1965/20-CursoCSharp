// ----------------------------------------
// Clase 07 Operadores Relacionales
// ----------------------------------------

// Estos operadores tambien son conocidos en las matemáticas tradicionales
// El resultado que devuelven estos operadores son: True o False

// Operador	Nombre	      Descripcion	                           Ejemplo
// ==	      igual          Verifica si 2 operando son iguales     x == y 
// !=	      distinto       Verifica si 2 operandos son distintos  x != y
// >	      mayor que      Verifica si es mayor que               x >  y
// <	      menor que      Verifica si es menor que               x <  y
// >=	      mayor o igual  Verifica si es mayor o igual que       x >= y
// <=		   menor o igual  Verifica si es menor o igual que       x <= y

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Definimos variables enteras
      int x=10, y=3;

      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 07 Operadores Relacionales");

      // Probamos los operadores
      bool resultado;
      System.Console.WriteLine("x == y :" + (x == y));
      resultado = x == y;
      System.Console.WriteLine("x == y :" + resultado);
      System.Console.WriteLine("x != y :" + (x != y));
      System.Console.WriteLine("x >  y :" + (x >  y));
      System.Console.WriteLine("x <  y :" + (x <  y));
      System.Console.WriteLine("x >= y :" + (x >= y));
      System.Console.WriteLine("x <= y :" + (x <= y));      
   }
}