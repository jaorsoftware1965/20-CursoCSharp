// ---------------------------------------------------------
// Curso de C# desde 0
// Clase 20 Sentencia break y continue
// -------------------------------------------------------------------

// La Sentencia break nos permite salir de cualquier ciclo en el que 
// nos encontremos, y ya vimos que tambien nos permite salir del switch

// La Sentencia continue nos sirve para indicar que la ejecución del ciclo
// regrese a la parte inicial


// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {         
      for (int i = 0; true; i++) 
      {
         // Sale del Ciclo cuando es 9
         if (i==9)
            break;
         Console.WriteLine(i);
      }

      // Deja una linea
      Console.WriteLine();

      for (int i = 0; true; i++) 
      {
         // Sale del Ciclo cuando es 9
         if (i==9)
            break;
         else
            // Va al inicio del Ciclo cuando es 5
            if (i==5)   
               continue;
         Console.WriteLine(i);
      }
   }    
}