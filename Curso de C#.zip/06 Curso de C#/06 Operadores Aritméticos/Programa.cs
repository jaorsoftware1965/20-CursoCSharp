// ----------------------------------------
// Clase 06 Operadores Aritméticos
// ----------------------------------------

// Son símbolos que nos permiten realizar las operaciones matemáticas
// comunes que conocemos y algunas adicionales.

// Operador	Nombre	      Descripcion	                        Ejemplo
// +	      Suma           Sumar 2 valores	                  x + y	
// -	      Resta	         Restar 2 valores	                  x - y	
// *	      Multiplicacion	Multiplicar 2 valores               x * y	
// /	      Division	      Dividir 1 valor entre otro	         x / y	
// %	      Residuo	      Obtener el residuio de la división  x % y	
// ++	      Incremento	   Incrementar en 1	                  x++,++x
// --    	Decremento	   Decrementar en 1                    x--,--x

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Definimos variables enteras
      int x=10, y=3;

      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 06 Operadores Artiméticos");

      // Probamos los operadores
      System.Console.WriteLine("x + y :" + (x + y));
      System.Console.WriteLine("x - y :" + (x - y));
      System.Console.WriteLine("x * y :" + (x * y));
      System.Console.WriteLine("x / y :" + (x / y));
      System.Console.WriteLine("x % y :" + (x % y));
      System.Console.WriteLine("x++   :" + (x++));
      System.Console.WriteLine("y--   :" + (y--));
      System.Console.WriteLine("++x   :" + (++x));
      System.Console.WriteLine("--y   :" + (--y));   
      
   }
}