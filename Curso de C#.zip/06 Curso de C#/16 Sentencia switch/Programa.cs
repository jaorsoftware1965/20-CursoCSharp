// ---------------------------------------------------------
// Curso de C# desde 0
// Clase 16 Sentencia switch
// ---------------------------------------------------------

// La Sentencia switch nos permite evaluar una expresión
// y ejecutar código dependiendiendo de varios posibles
// valores conocidos de ella.

// switch(expression) 
// {
//   case x:
//     // code block
//     break;
//   case y:
//     // code block
//     break;
//   default:
//     // code block
//     break;
// }

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {         
      // Variables
      int    iDiaSemana;

      // Creamos una variable y a su vez ejecutamos la función para que lea
      Console.WriteLine("Capture dia Semana:");
      iDiaSemana = Convert.ToInt32(Console.ReadLine());

      // Evalua el Dia
      switch(iDiaSemana) 
      {
         case 1:
            Console.WriteLine("Domingo");            
            break;
         case 2:
            Console.WriteLine("Lunes");
            break;
         case 3:
            Console.WriteLine("Martes");
            break;   
         case 4:
            Console.WriteLine("Miercoles");
            break;   
         case 5:
            Console.WriteLine("Jueves");
            break;
         case 6:
            Console.WriteLine("Viernes");
            break;
         case 7:
            Console.WriteLine("Sábado");
            break;   
         default:
            Console.WriteLine("Dia Erroneo");
            break;
      }

      // Creamos una variable y a su vez ejecutamos la función para que lea
      string sDiaSemana;
      Console.WriteLine("Capture Nombre del Dia:");
      sDiaSemana = Console.ReadLine();

      // Evalua el Dia
      switch(sDiaSemana) 
      {
         case "Lunes":
         case "Monday":
            Console.WriteLine("2");
            break;
         case "Martes":
            Console.WriteLine("3");
            break;
         case "Miercoles":
            Console.WriteLine("4");
            break;   
         case "Jueves":
            Console.WriteLine("5");
            break;   
         case "Viernes":
            Console.WriteLine("6");
            break;
         case "Sabado":
            Console.WriteLine("7");
            break;
         case "Domingo":
            Console.WriteLine("1");
            break;   
         default:
            Console.WriteLine("Dia Erroneo");
            break;
      }  
   }    
}