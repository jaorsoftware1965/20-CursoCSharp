// ---------------------------------------------------------
// Curso de C# desde 0
// Clase 18 Ciclo While
// -------------------------------------------------------------------

// El Ciclo While nos permite realizar ciclos de instrucciones que se
// repiten mientras que una condicion se cumpla



// while (condition) 
// {
//   // code block to be executed
// }

// do 
// {
//   // code block to be executed
// }
// while (condition);


// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {               
      int i = 0;
      while (i < 5) 
      {
         Console.WriteLine(i);
         i++;
      }
      Console.WriteLine();

      //i = 0;
      do 
      {
         Console.WriteLine(i);
         i++;
      }
      while (i < 5);
      Console.WriteLine();

      i = 1;
      while (i < 11) 
      {
         Console.WriteLine("5 x " + i +" = "+ 5 * i);
         i++;
         i++;
      }
   }    
}