// ----------------------------------------
// Clase 08 Operadores Lógicos
// ----------------------------------------

// Estos operadores tambien son conocidos en las matemáticas tradicionales
// Y tambien en el Álgebra Booleana

// Los operadores son: && (And), || (Or) y ! (Not).

// Tabla de Verdad de AND
// Operando1   Operador Operando2   Resultado
// True        &&       True        True
// True        &&       False       False
// False       &&       True        False
// False       &&       False       False

// Tabla de Verdad de OR
// Operando1   Operador Operando2   Resultado
// True        ||       True        True
// True        ||       False       True
// False       ||       True        True
// False       ||       False       False

// Tabla de Verdad de NOT
// Operador Oerando     Resultado
// !        True        False
// !        False       True


// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Definimos variables enteras
      int x=10, y=3;

      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 07 Operadores Relacionales");

      System.Console.Write("x < 5 && x < y:    ");
      System.Console.WriteLine(x < 5 && x < y);	

      System.Console.Write("x < 5 || x < y:    ");
      System.Console.WriteLine(x < 5 || x < y);	

      System.Console.Write("!(x < 5 && x < y): ");
      System.Console.WriteLine(!(x < 5 && x < y));	

      System.Console.Write("!(x < 5 || x < y): ");
      System.Console.WriteLine(!(x < 5 || x < y));	

      System.Console.Write("!(x < 5) && x < y: ");
      System.Console.WriteLine(!(x < 5) && x < y);

      System.Console.Write("x < 5 || !(x < y): ");
      System.Console.WriteLine(x < 5 || !(x < y));	

   }
}