// ----------------------------------------
// Clase 09 Operadores de Bit
// ----------------------------------------

// Estos operadores permiten realizar una operación con números
// manejándolos como bit's

//  100  10  1
//    C   D  U
//    1   3  4
// 4 + 30 + 100 = 134    0,1,2,3,4,5,6,7,8,9

//  16  8  4  2  1       0,1
//   1  0  1  0  0 = 20 en decimal
//   0  1  1  0  1 = 13 en decimal

// Operador    Descripción                Ejemplo
// &	         Operador And               A = 10  = 1010
//                                        B = 12  = 1100
//                                        A & B   = 1000 = 8 en decimal

// |	         Operador Or                A = 10  = 1010
//                                        B = 12  = 1100
//                                        A | B   = 1110 = 14 en decimal

// ^	         Operador Xor               A = 10  = 1010
//                                        B = 12  = 1100
//                                        A ^ B   = 0110 = 6 en decimal

// ~	         Operador complemento a 2	Si A = 10 (~A) = -11

// <<	         Desplaza bits izquierda	   Si A = 10,  A <<  = 101000 = 40

// >>	         Desplaza bits derecha      Si A = 10,	A >> 1 = 0010 = 2

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Definimos variables enteras
      int A = 10,  B = 12;

      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 07 Operadores Relacionales");

      System.Console.WriteLine("A & B :"  + (A & B));
      System.Console.WriteLine("A | B :"  + (A | B));
      System.Console.WriteLine("A ^ B :"  + (A ^ B));
      System.Console.WriteLine("~A    :"  + ( ~A));
      System.Console.WriteLine("A << 2 :" + (A << 2));
      System.Console.WriteLine("A >> 2 :" + (A >> 2));         
   }
}