// ---------------------------------------------------------
// Curso de C# desde 0
// Clase 14 Strings Manejo
// ---------------------------------------------------------

// A continuación veremos algunas funciones que son 
// fundamentales en el manejo de Strings

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {         
      // Variables
      string sNombre   = "Juan Alberto";
      string sApellido = "Perez";

      // Longitud
      Console.WriteLine("Nombre : " + sNombre);
      Console.WriteLine("Nombre Longitud: " + sNombre.Length);

      // Concatenación con Operador
      Console.WriteLine("Nombre Completo: " + sNombre + " " + sApellido);      

      // Concatenación Operador
      string sNombreCompleto = string.Concat(sNombre, " ", sApellido);

      // Concatena
      Console.WriteLine("Nombre Completo: " + sNombreCompleto);      

      // Subcadenas
      Console.WriteLine(sNombre);
      Console.WriteLine(sNombre[0]);
      Console.WriteLine(sNombre[sNombre.Length-1]);

      // Buscar
      Console.WriteLine("Buscar n: " + sNombre.IndexOf("n"));
      Console.WriteLine("SubCadena desde 3 : " + sNombre.Substring(3));
      Console.WriteLine("SubCadena hasta 3 : " + sNombre.Substring(0,3));

      // Sumando Numeros con Cadenas
      int x = 10;
      int y = 20;
      string z = "["+ x + y +"]";
      Console.WriteLine(z);


   }
}