// ----------------------------------------
// Clase 10 Operadores de Asignación
// ----------------------------------------

// Estos operadores permiten realizar una operación y adicionalmente
// realizan una asignación

// Operador    Descripción                Ejemplo
// =	         Operador de Asignación     x = y + z; a x asigna y+z
// +=	         Suma y Asigna              C += A es equivalente a C = C + A
// -=	         Resta y Asigna             C -= A es equivalente a C = C - A
// *=	         Multiplica y Asigna        C *= A es equivalente a C = C * A
// /=	         Divide y Asigna            C /= A es equivalente a C = C / A
// %=	         Residuo y Asigna           C %= A es equivalente a C = C % A
// <<=	      Despl Izq y Asigna         C <<= 2 es equivalente a C = C << 2
// >>=	      Despl Der y Asigna         C >>= 2 es equivalente a C = C >> 2
// &=	         Bit And y Asigna	         C &= 2 es equivalente a C = C & 2
// ^=	         Bit Xor y Asigna           C ^= 2 es equivalente a C = C ^ 2
// |=          Bit Or  y Asigna           C |= 2 es equivalente a C = C | 2

// Usamos un espacio de Nombres
using System;

// Definimos la clase de la aplicación
class Programa
{
   // Establecemos la función principal
   public static void Main()
   {
      // Definimos variables enteras
      int C=2, A=10;

      // Mandamos un Mensaje a la Pantalla
      System.Console.WriteLine("Clase 10 Operadores de Asignación");

      System.Console.WriteLine("Ccls += A: " + (C += A));
      System.Console.WriteLine("C -= A: " + (C -= A));
      System.Console.WriteLine("C *= A: " + (C *= A));
      System.Console.WriteLine("C /= A: " + (C /= A));
      System.Console.WriteLine("C %= A: " + (C %= A));
      System.Console.WriteLine("C << 2: " + (C <<= 2));
      System.Console.WriteLine("C >> 2: " + (C >>= 2));
      System.Console.WriteLine("C &= A: " + (C &= A));
      System.Console.WriteLine("C ^= A: " + (C ^= A));
      System.Console.WriteLine("C |= A: " + (C |= A));

      //   0010     0010    1000
      //   1010     1010    1010
      // & 0010   ^ 1000  | 1010 
      
   }
}